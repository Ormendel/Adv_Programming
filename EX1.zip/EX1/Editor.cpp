#include "Editor.h"
#include "Document.h"
#include <sstream>
#include <iostream>

using namespace std;

void Editor::loop()
{
    string input;

    while (true)
    {
        getline(cin, input);
        string c = input.substr(0,1);
        char command = c[0];
        int number;

        /* number was entered */
        if(isdigit(command))
        {
            number = atoi(input.c_str());
            Editor::doc.move_pointer_to(number);
            cin.clear();
            continue;
        }

        switch(command)
        {
            
            /* add to pointer */
            case '+':
                input = input.substr(1,input.size()-1);
                number = atoi(input.c_str());
                Editor::doc.add_to_pointer(number);
                cin.clear();
                break;
            
            /* subtruct from pointer */
            case '-':
                input = input.substr(1,input.size()-1);
                number = atoi(input.c_str());
                Editor::doc.subtruct_from_pointer(number);
                cin.clear();
                break;
            
            /* go to last line */
            case '$':
                Editor::doc.go_to_lastRow();
                cin.clear();
                break;
            
            /* add row after current row */
            case 'a':
            {
                bool flag = false;
                string txt;
                while(true)
                {
                    getline(cin,txt);
                    flag = Editor::doc.add_row_after(txt);
                    if(!flag)
                        break;
                }
                cin.clear();
                break;
            }

            /* add row before current row */
            case 'i':
            {
                bool flag = false;
                string txt;
                while(Editor::doc.get_rows() != 0)
                {
                    getline(cin,txt);
                    flag = Editor::doc.add_row_before(txt);
                    if(!flag)
                        break;
                }
                if(Editor::doc.get_rows() != 0)
                    Editor::doc.after_i();
                cin.clear();
                break;
            }
            
            /* change current row */
            case 'c':
            {
                bool flag = false;
                string txt;
                int i = 0;
                while(true)
                {
                    getline(cin,txt);
                    flag = Editor::doc.change_current_row(txt);
                    if(!flag)
                        break;
                    i++;
                }
                Editor::doc.after_c(i);
                cin.clear();
                break;
            }

            /* delete current row */
            case 'd':
                Editor::doc.delete_current_row();
                cin.clear();
                break;

            /* go to <txt> row */
            case '/':
                input = input.substr(1,input.size()-2);
                Editor::doc.search_for_text(input);
                cin.clear();
                break;

            /* swap text */
            case 's':
            {
                string old_s = input.substr(2,input.size()-3);
                int index = 0;
                for(int i = 0; i < old_s.size(); i++){
                    if(old_s[i] == '/'){
                        break;
                    }
                    index++;
                }
                string tmp = old_s;
                old_s = old_s.substr(0,index);
                string new_s = tmp.substr(index+1,tmp.size()-old_s.size()-1);
                Editor::doc.swap_text(old_s,new_s);
                cin.clear();
                break;
            }

            /* join current row with the one after it */
            case 'j':
                Editor::doc.join();
                cin.clear();
                break;

            /* write to file */
            case 'w':
            {
                input = input.substr(2,input.size()-1);
                Editor::doc.write_to_file(input);
                cin.clear();
                break;
            }

            /* quit program */
            case 'q':
                exit(0);

            default:
                cin.clear();
                cout << "?" << endl;
                break;
        }
    }
}