#ifndef EDITOR_H
#define EDITOR_H



#include "Document.h"

class Editor
{
    private: 
        Document doc;

    public:
        /*Constructors*/
        Editor(){};
        Editor(std::string filename):doc(filename){};

        /*Destructors*/
        ~Editor(){};

        /*Functions*/
        void loop();
};

#endif //ndef EDITOR_H