#include <iostream> 
#include <math.h> 

/* template fibonacci function.
begin = start of iterator.
end = end of iterator.
function returns true if the given input is
sub set of the fibonacci set, false otherwise.
*/
template <typename T>
bool Fib(T begin, T end)
{
    if (*begin <= 0)
    {
        return false;
    }

    int n1 = 1;
    int n2 = 1;
    int ans = 0;
    if (*begin == 1)
    {
        begin++;
        if (*begin != 1 && *begin > 2)
        {
            return false;
        }
        begin++;
    }

    while (begin != end)
    {
        ans = n1 + n2;
        n1 = n2;
        n2 = ans;//Recrursive
        if (*begin != ans && *begin < ans)
        {
            return false;
        }
        if (*begin == ans)
        {
            begin++;
        }
    }
    return true;
}

/*template Transpose function.
begin = start of iterator.
end = end of iterator.
function returns begin if the set size is even
and transposes every adjecent elements,
otherwise returns end.
*/
template <typename T>
T Transpose(T begin, T end)
{
    size_t count = 0;
    
    for(auto it = begin; it != end;++it)
    {
        count++;
    }

    if(count%2 == 1)//We don't swap
    {
        return begin;
    }

    for(auto it = begin; it != end;++it)
    {
        T pointer = it++;
        auto t = *it;
        *it = *pointer;
        *pointer = t;
    }

    return end;
}

/*template Transform function.
begin = start of first iterator.
end = end of first iterator.
b = start of second iterator.
Op = function.
function returns begin of second iterator
and the second iterator contains the result of the 
function - Op on every adjecent elements.
*/
template <typename T1 ,typename T2, typename op>
T2 Transform2(T1 begin, T1 end, T2 b, op Op)
{
    for(auto it = begin; it != end;++it)
    {
        T1 pointer = it++;
        if(it == end)
        {
            break;
        }
        *b = Op(*pointer,*it);
        b++;
    }
    return b;
}