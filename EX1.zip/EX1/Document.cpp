#include "Document.h"
#include <fstream>
#include <algorithm>
#include <iterator>
#include <stdlib.h>

#include <iostream>

using namespace std;

/*Constructors*/

Document::Document() //Default constructor - we are not getting file name from user
{
    numOfRows = 0;
    row_pointer = 0;
}

Document::Document(string _file_name) //Constructor with given file name
{
    numOfRows = 0;
    row_pointer = 0;
    ifstream inFile;
    inFile.open(_file_name);
    if (inFile.fail())//File is not opened as expected
    {
        cerr << "Error occured while trying opening the file: " <<_file_name<<endl;
        inFile.close();
        exit(1);
    }
    string line;
    while (getline(inFile, line))
    {
        data.push_back(line);
        numOfRows++;
    }
    inFile.close();
}

/*Destructors*/
Document::~Document() 
{
    data.clear();
    data.shrink_to_fit();
    numOfRows = 0;
    row_pointer = 1;
}

/*functions*/

/* number case */
bool Document::move_pointer_to(int target)
{
    if(target > numOfRows || target < 1)
    {
        cout <<"Line "<<target<<" doesn't exsist in the file!" << endl;
        return false;
    }
    row_pointer = target;
    // cout << "pointer is now at row #" << row_pointer << endl;
    //Printing lines - unnecassary?
    // for (auto line = data.begin(); line != data.end(); ++line){
    //     cout << *line << endl;
    // } 
    return true;
}

/* '+' case */
bool Document::add_to_pointer(int add)
{
    if(row_pointer + add > numOfRows)
    {
        cout << "Adding this number will cause exception from bound!" << endl;
        return false;
    }
    row_pointer += add;
    cout << "pointer is now at row #" << row_pointer << endl;
    //Printing lines - unnecassary?
    // for (auto line = data.begin(); line != data.end(); ++line){
    //     cout << *line << endl;
    // }  
    return true;
}

/* '-' case */
bool Document::subtruct_from_pointer(int sub)
{
    if(row_pointer - sub < 1)
    {
        cout << "incorrect input" << endl;
        return false;
    }
    row_pointer -= sub;
    // cout << "pointer is now at row #" << row_pointer << endl; 
    return true;
}

/* '$' case */
bool Document::go_to_lastRow()
{
    row_pointer = numOfRows;
    // cout << "pointer is now at row #" << row_pointer << endl;  
    return true;
}

/* 'a' case */
bool Document::add_row_after(string row)
{
    if(row.size() == 0)//Case of empty row
        return true;
    if(row == ".")//We stop adding lines
        return false;
    vector<string>::iterator it;
    it = data.begin();
    data.insert(it+row_pointer,row);
    row_pointer++;
    numOfRows++;//Updating num of total rows in document
    return true;
}

/* 'i' case */
bool Document::add_row_before(string row)
{
    if(numOfRows == 0)//Out of bounds
    {
        cout << "incorrect input" << endl;
        return false;
    }
    if(row.size() == 0)
        return true;
    if(row == ".")
        return false;
    int tmp = row_pointer;
    vector<string>::iterator it;
    it = data.begin();
    data.insert(it+row_pointer-1,row);
    numOfRows++;
    row_pointer++;
    return true;
}

/* correcting the row's pointer */
bool Document::after_i()
{
    row_pointer--;
    return true;
}

/* 'c' case */
bool Document::change_current_row(string row)
{
    if(numOfRows == 0)
    {
        cout << "The document is empty, nothing to change" << endl;
        return false;
    }
    if(row.size() == 0)
        return true;
    if(row == ".")
        return false;
    add_row_after(row);
    return true;
}

/* 'd' case */
bool Document::delete_current_row()
{
    if(numOfRows == 0)
    {
        cout << "nothing to delete" << endl;
        return false;
    }
    vector<string>::iterator it;
    it = data.begin();
    data.erase(it+row_pointer-1);
    if(numOfRows == 1)
        row_pointer--;
    numOfRows--;
    // cout << "row_pointer: " << row_pointer << " rows: " << numOfRows << endl; 
    return true;
}

bool Document::after_c(int i)
{
    // cout << "i is " << i << endl;
    row_pointer -= i;
    delete_current_row();
    row_pointer += i-1;
    return true;
}



/* '/text/' case */
bool Document::search_for_text(string text)
{
    if(numOfRows == 0)
    {
        cout << "Document is empty" << endl;
        return false;
    }
    int temp_pointer = row_pointer;
    bool found = false;

    /* first search from current row */
    for (int i = row_pointer-1; i < numOfRows; ++i)
    {
        if (data.at(i).find(text) != -1)
        {
            //int index = data.at(i).find(text);
            found = true;
            break;   
        }
        row_pointer++;
    }

    /* starting the search from the beggining */
    if(!found)
    {
        row_pointer = 1;
        for (int i = 0; i < numOfRows; ++i)//Index starts from 0 when going through the rows
        {
            if (data.at(i).find(text) != -1)
            {
                //int index = data.at(i).find(text);
                found = true;
                break;           
            }
            row_pointer++;
        }
    }

    /* the word was not found */
    if(!found)
    {
        row_pointer = temp_pointer;
        cout << "could not find the word: " << text << endl;
        return false;
    }
    
    cout << "The word was found at line #" << row_pointer << endl;
    // cout << "row_pointer: " << row_pointer << " rows: " << numOfRows << endl;
    return true;
}

/* s/old/new/ case*/
bool Document::swap_text(string old_t, string new_t)
{
    bool flag = search_for_text(old_t);
    if(!flag)
        return false;
    int index;//row_pointer is updated after activating search_for_text function
    if(data.at(row_pointer-1).find(old_t) != -1)
        index = data.at(row_pointer-1).find(old_t);
    else
    {
        cout << "could not find the word: " << old_t << endl;
        return false;
    }
    data.at(row_pointer-1).replace(index,old_t.size(),new_t);
    return true;
}

/* 'j' case */
bool Document::join()
{
    if(numOfRows == 1 || row_pointer == numOfRows)
    {
        std::cout << "There is only single line, nothing to join" << std::endl;
        return false;
    }
    data.at(row_pointer-1) += " ";
    data.at(row_pointer-1) += data.at(row_pointer);
    std::vector<std::string>::iterator it;
    it = data.begin()+row_pointer;
    data.erase(it);
    numOfRows--;
    return true;
}

/* 'w' case */
bool Document::write_to_file(string file)
{
    vector<string> tmp;
    copy(data.begin(), data.end(), back_inserter(tmp));

    fstream inFile;
    inFile.open(file);
    if (inFile.fail())//Something went wrong while trying opening the file 
    {
        cerr<<"Can not open file"<<endl;
        // ofstream outfile (file);
        // while(!tmp.empty())
        // {
        //     outfile << tmp.front() << endl;
        //     tmp.erase(tmp.begin());
        // }
        // outfile.close();
    }
    else
    {
        while(!tmp.empty())
        {
            inFile << tmp.front() << endl;
            tmp.erase(tmp.begin());
        }
    }
    inFile.close();

    return true;
}




