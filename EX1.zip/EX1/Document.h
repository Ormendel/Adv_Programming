#ifndef DOCUMENT_H
#define DOCUMENT_H

#include <vector>
#include <string>


class Document
{
    private:

        std::vector<std::string> data;
        int numOfRows;
        int row_pointer;
        std::string file_name;

    public:
    /*Constructors*/
        Document();//Default constructor - we are not getting file name from user
        Document(std::string _file_name);//Constructor with given file name

    /*Destructors*/
        ~Document();

    /*Getters*/
        unsigned int get_rows(){return numOfRows;}
        const char* get_file_name(){return file_name.c_str();}//std::c_str - copy of string file name
        
    /*Functions*/
    bool move_pointer_to(int target);//V
    bool add_to_pointer(int add_num);//V
    bool subtruct_from_pointer(int sub_num);//V
    bool go_to_lastRow();//V
    bool add_row_before(std::string row);//V
    bool add_row_after(std::string row);//V
    bool after_i();//V
    bool change_current_row(std::string row);//V
    bool after_c(int i);//V
    bool delete_current_row();//V
    bool search_for_text(std::string text);//V
    bool swap_text(std::string old_t, std::string new_t);//V
    bool join();//V
    bool write_to_file(std::string file);//V
    bool quit();
    
};

#endif //ndef DOCUMENT_H